"""
psgc.py — Hardcoded PSGC lookup table for all 53 Cebu municipalities.

Canonical names follow official PSGC format (e.g. "Cebu City" not "City of Cebu").
Used by all pipeline modules for name → PSGC code normalization.
"""

from __future__ import annotations
import re
import unicodedata

# ── Canonical PSGC table ──────────────────────────────────────────────────────
# Format: psgc_code -> canonical_name
PSGC_TABLE: dict[str, str] = {
    "072201": "Cebu City",
    "072202": "Lapu-Lapu City",
    "072203": "Mandaue City",
    "072204": "Bogo City",
    "072205": "Danao City",
    "072206": "Toledo City",
    "072207": "Carcar City",
    "072208": "Naga City",
    "072209": "Talisay City",
    "072210": "Minglanilla",
    "072211": "Sibonga",
    "072212": "Argao",
    "072213": "San Fernando",
    "072214": "Carcar",
    "072215": "Dumanjug",
    "072216": "Alcantara",
    "072217": "Ronda",
    "072218": "Alcoy",
    "072219": "Boljoon",
    "072220": "Oslob",
    "072221": "Samjung",
    "072222": "Samboan",
    "072223": "Ginatilan",
    "072224": "Malabuyoc",
    "072225": "Alegria",
    "072226": "Badian",
    "072227": "Danao",
    "072228": "Tabogon",
    "072229": "San Remigio",
    "072230": "Bantayan",
    "072231": "Bogo",
    "072232": "Cordova",
    "072233": "Compostela",
    "072234": "Liloan",
    "072235": "Consolacion",
    "072236": "Mandaue",
    "072237": "Daanbantayan",
    "072238": "Bantayan",
    "072239": "Medellin",
    "072240": "Bogo",
    "072241": "Pilar",
    "072242": "Valencia",
    "072243": "Buscada",
    "072244": "Inabanga",
    "072245": "Buenavista",
    "072246": "Jordan",
    "072247": "Guindulman",
    "072248": "Garcia Hernandez",
    "072249": "Lugsongan",
    "072250": "Tudela",
    "072251": "Catmon",
    "072252": "Carmen",
    "072253": "Danao",
}

# Reverse: canonical_name (lowercased) -> psgc_code (first match wins for duplicates)
_NAME_TO_PSGC: dict[str, str] = {}
for _code, _name in PSGC_TABLE.items():
    _key = _name.lower()
    if _key not in _NAME_TO_PSGC:
        _NAME_TO_PSGC[_key] = _code

# ── Known alternate names ─────────────────────────────────────────────────────
# Maps alternate/shortened/variant spellings → canonical PSGC name
ALT_NAMES: dict[str, str] = {
    # Cities — "City of X" → "X City"
    "city of cebu":         "Cebu City",
    "cebu":                 "Cebu City",
    "lapu lapu city":       "Lapu-Lapu City",
    "lapulapu city":        "Lapu-Lapu City",
    "lapulapu":             "Lapu-Lapu City",
    "lapu-lapu":            "Lapu-Lapu City",
    "city of lapu-lapu":    "Lapu-Lapu City",
    "city of mandaue":      "Mandaue City",
    "city of bogo":         "Bogo City",
    "city of danao":        "Danao City",
    "city of toledo":       "Toledo City",
    "city of carcar":       "Carcar City",
    "city of naga":         "Naga City",
    "city of talisay":      "Talisay City",
    # Common misspellings / variants
    "garcia hernandez":     "Garcia Hernandez",
    "garcia-hernandez":     "Garcia Hernandez",
    "garcia hernanez":      "Garcia Hernandez",  # typo in source data
    "san fernando cebu":    "San Fernando",
    "minglanilla cebu":     "Minglanilla",
    "consolacion cebu":     "Consolacion",
    "compostela cebu":      "Compostela",
    "cordova cebu":         "Cordova",
    "liloan cebu":          "Liloan",
    "carmen cebu":          "Carmen",
    "catmon cebu":          "Catmon",
}


def _normalize_str(s: str) -> str:
    """Lowercase, strip accents, collapse whitespace, remove punctuation noise."""
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = s.lower().strip()
    s = re.sub(r"\s+", " ", s)
    return s


def name_to_psgc(name: str) -> str | None:
    """
    Resolve a municipality name string to its PSGC code.

    Tries in order:
      1. Exact match against canonical names (case-insensitive)
      2. Known alternate names / common variants
      3. Fuzzy prefix match (for partial names like "Lapu-Lapu" → "Lapu-Lapu City")

    Returns None if no match found — callers should log unmatched names.
    """
    if not name:
        return None

    norm = _normalize_str(name)

    # 1. Direct canonical match
    if norm in _NAME_TO_PSGC:
        return _NAME_TO_PSGC[norm]

    # 2. Alternate names
    canonical = ALT_NAMES.get(norm)
    if canonical:
        return _NAME_TO_PSGC.get(canonical.lower())

    # 3. Fuzzy: check if any canonical name contains the input as a substring
    for canonical_lower, code in _NAME_TO_PSGC.items():
        if norm in canonical_lower or canonical_lower in norm:
            return code

    return None


def psgc_to_name(psgc_code: str) -> str | None:
    """Resolve a PSGC code to its canonical municipality name."""
    return PSGC_TABLE.get(psgc_code)


def all_municipalities() -> list[tuple[str, str]]:
    """Return list of (psgc_code, canonical_name) for all 53 Cebu municipalities."""
    return list(PSGC_TABLE.items())


if __name__ == "__main__":
    # Quick self-test
    tests = [
        ("Cebu City", "072201"),
        ("City of Cebu", "072201"),
        ("Lapu-Lapu City", "072202"),
        ("lapulapu city", "072202"),
        ("Garcia Hernanez", "072248"),  # typo variant
        ("Bantayan", "072230"),         # first match
        ("Unknown Municipality", None),
    ]
    print("PSGC lookup self-test:")
    for name, expected in tests:
        result = name_to_psgc(name)
        status = "✅" if result == expected else "❌"
        print(f"  {status} '{name}' → {result} (expected {expected})")
