"""
scraper_doe.py — DOE (Department of Energy) fuel allocation scraper.

Strategy (per docs/001):
  Primary:  Download and parse DOE's publicly available PDF statistical reports.
  Fallback: Cloudscraper for basic Cloudflare bypass.
  Blocked:  Playwright stub (marked TODO) for full JS-rendered pages.

Output CSV columns: psgc_code,municipality,value,date,source
Value unit: liters (fuel allocation per municipality)

Known URLs to try (as of April 2026):
  - doe.gov.ph/petroleum-reports — monthly fuel allocation PDFs
  - doe.gov.ph/energy-statistics — annual statistical reports
  All blocked by Cloudflare as of writing.
"""

from __future__ import annotations

import asyncio
import csv
import io
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, date, timezone
from pathlib import Path

import aiohttp

# Optional imports — graceful degradation if not installed
try:
    import cloudscraper
    _CLOUDSCRAPER_AVAILABLE = True
except ImportError:
    _CLOUDSCRAPER_AVAILABLE = False

try:
    import pdfplumber
    _PDFPLUMBER_AVAILABLE = True
except ImportError:
    _PDFPLUMBER_AVAILABLE = False

try:
    import fitz  # PyMuPDF
    _FITZ_AVAILABLE = True
except ImportError:
    _FITZ_AVAILABLE = False

sys.path.insert(0, str(Path(__file__).parent))
from psgc import name_to_psgc, psgc_to_name

OUTPUT_DIR = Path(__file__).parent / "output"
SOURCE_TAG = "DOE"

# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class FuelRecord:
    psgc_code:    str
    municipality: str
    value:        float          # liters
    date:         str            # ISO date YYYY-MM-DD
    source:       str = SOURCE_TAG


@dataclass
class ScrapeResult:
    records:   list[FuelRecord] = field(default_factory=list)
    errors:    list[str]        = field(default_factory=list)
    source_url: str = ""
    fetched_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ── Known DOE report URLs ─────────────────────────────────────────────────────
# These are the best-known public PDF endpoints. Update as DOE publishes new reports.
# All are currently Cloudflare-protected (status as of April 2026).

DOE_PDF_URLS = [
    # Monthly petroleum supply/distribution reports
    "https://www.doe.gov.ph/sites/default/files/pdf/petroleum/fuel_monitoring_report_latest.pdf",
    # Annual energy statistics (has regional breakdowns)
    "https://www.doe.gov.ph/sites/default/files/pdf/energy_statistics/ces_latest.pdf",
    # Region 7 specific fuel allocation (if published)
    "https://www.doe.gov.ph/sites/default/files/pdf/petroleum/region7_fuel_allocation.pdf",
]

DOE_REPORT_INDEX_URL = "https://www.doe.gov.ph/petroleum-reports"


# ── PDF parsing ───────────────────────────────────────────────────────────────

def _parse_pdf_bytes_pdfplumber(pdf_bytes: bytes, report_date: str) -> list[FuelRecord]:
    """
    Parse DOE PDF using pdfplumber (preferred — better table extraction).

    DOE fuel allocation reports typically have tables with columns like:
      Province | Municipality | Allocation (liters) | Date
    or
      Region | Municipality/City | Gasoline | Diesel | Kerosene
    """
    records: list[FuelRecord] = []

    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            tables = page.extract_tables()
            for table in tables:
                if not table:
                    continue
                # Try to find the header row to identify columns
                header = [str(c).lower().strip() if c else "" for c in table[0]]

                # Look for municipality column
                muni_col = next(
                    (i for i, h in enumerate(header)
                     if any(kw in h for kw in ["municipality", "city", "lgu", "locality"])),
                    None,
                )
                # Look for value column (fuel volume)
                val_col = next(
                    (i for i, h in enumerate(header)
                     if any(kw in h for kw in ["allocation", "volume", "liters", "liter", "total"])),
                    None,
                )

                if muni_col is None or val_col is None:
                    continue

                for row in table[1:]:
                    if not row or len(row) <= max(muni_col, val_col):
                        continue
                    muni_raw = str(row[muni_col] or "").strip()
                    val_raw  = str(row[val_col]  or "").strip()

                    if not muni_raw or not val_raw:
                        continue

                    # Parse numeric value (remove commas, units, etc.)
                    val_clean = re.sub(r"[^\d.]", "", val_raw)
                    if not val_clean:
                        continue

                    psgc = name_to_psgc(muni_raw)
                    if not psgc:
                        # Not a Cebu municipality — skip silently
                        continue

                    records.append(FuelRecord(
                        psgc_code=psgc,
                        municipality=psgc_to_name(psgc) or muni_raw,
                        value=float(val_clean),
                        date=report_date,
                        source=SOURCE_TAG,
                    ))

    return records


def _parse_pdf_bytes_pymupdf(pdf_bytes: bytes, report_date: str) -> list[FuelRecord]:
    """
    Fallback PDF parser using PyMuPDF (fitz) — plain text extraction.
    Less accurate for tables but works when pdfplumber can't parse properly.
    """
    records: list[FuelRecord] = []
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")

    # Pattern: looks for lines like "Cebu City  125,000" or "Toledo  45,230.5"
    line_pattern = re.compile(
        r"([A-Za-z\-\s]+(?:City|Municipality)?)\s+([\d,]+(?:\.\d+)?)",
        re.IGNORECASE,
    )

    for page in doc:
        text = page.get_text()
        for match in line_pattern.finditer(text):
            muni_raw = match.group(1).strip()
            val_raw  = match.group(2).strip().replace(",", "")

            psgc = name_to_psgc(muni_raw)
            if not psgc:
                continue

            try:
                records.append(FuelRecord(
                    psgc_code=psgc,
                    municipality=psgc_to_name(psgc) or muni_raw,
                    value=float(val_raw),
                    date=report_date,
                    source=SOURCE_TAG,
                ))
            except ValueError:
                continue

    doc.close()
    return records


def parse_pdf_bytes(pdf_bytes: bytes, report_date: str) -> list[FuelRecord]:
    """Parse PDF bytes using best available library."""
    if _PDFPLUMBER_AVAILABLE:
        return _parse_pdf_bytes_pdfplumber(pdf_bytes, report_date)
    elif _FITZ_AVAILABLE:
        return _parse_pdf_bytes_pymupdf(pdf_bytes, report_date)
    else:
        raise RuntimeError(
            "No PDF parsing library available. "
            "Install pdfplumber (preferred): pip install pdfplumber\n"
            "Or PyMuPDF: pip install pymupdf"
        )


# ── HTTP fetching ─────────────────────────────────────────────────────────────

async def _fetch_url_aiohttp(url: str) -> bytes | None:
    """Plain aiohttp fetch — works for non-protected URLs."""
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "application/pdf,*/*",
    }
    try:
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=60)) as resp:
                if resp.status == 200:
                    return await resp.read()
                print(f"  HTTP {resp.status} from {url}")
                return None
    except Exception as e:
        print(f"  aiohttp error: {e}")
        return None


def _fetch_url_cloudscraper(url: str) -> bytes | None:
    """Cloudscraper fetch — bypasses basic Cloudflare JS challenge."""
    if not _CLOUDSCRAPER_AVAILABLE:
        print("  cloudscraper not installed: pip install cloudscraper")
        return None
    try:
        scraper = cloudscraper.create_scraper()
        resp = scraper.get(url, timeout=60)
        if resp.status_code == 200:
            return resp.content
        print(f"  cloudscraper HTTP {resp.status_code} from {url}")
        return None
    except Exception as e:
        print(f"  cloudscraper error: {e}")
        return None


async def _fetch_url_playwright(url: str) -> bytes | None:
    """
    TODO: Playwright fallback for Cloudflare-protected pages that require
    full browser rendering. Not yet implemented.

    Steps needed:
      1. Launch Chromium headless
      2. Navigate to the DOE reports index page
      3. Find PDF download links
      4. Download PDFs via the browser context (to inherit cookies/session)

    Install: pip install playwright && playwright install chromium
    """
    raise NotImplementedError(
        "Playwright scraper not implemented yet.\n"
        "To implement:\n"
        "  1. pip install playwright\n"
        "  2. playwright install chromium\n"
        "  3. Implement browser-based navigation to:\n"
        f"     {DOE_REPORT_INDEX_URL}\n"
        "  4. Find PDF links and download with page.goto()"
    )


async def fetch_pdf(url: str, use_cloudscraper: bool = True) -> bytes | None:
    """
    Try to fetch a PDF from url using available methods in order:
      1. Plain aiohttp (fastest, fails on Cloudflare)
      2. Cloudscraper (bypasses basic Cloudflare)
      3. Playwright (TODO — for full JS challenge bypass)
    """
    print(f"  Fetching: {url}")

    # Try 1: plain aiohttp
    data = await _fetch_url_aiohttp(url)
    if data and data[:4] == b"%PDF":
        print(f"  ✅ Got PDF via aiohttp ({len(data):,} bytes)")
        return data

    # Try 2: cloudscraper
    if use_cloudscraper:
        print("  Trying cloudscraper...")
        data = _fetch_url_cloudscraper(url)
        if data and data[:4] == b"%PDF":
            print(f"  ✅ Got PDF via cloudscraper ({len(data):,} bytes)")
            return data

    # Try 3: Playwright (not implemented)
    print("  ⚠  All fetch methods failed (Playwright TODO).")
    return None


# ── Main scraper ──────────────────────────────────────────────────────────────

async def scrape_doe_fuel(
    report_date: str | None = None,
    pdf_urls: list[str] | None = None,
) -> ScrapeResult:
    """
    Scrape DOE fuel allocation data for Cebu municipalities.

    Args:
        report_date: ISO date string for the report (default: today).
        pdf_urls:    Override the default list of PDF URLs to try.

    Returns ScrapeResult with records and any errors encountered.
    """
    result = ScrapeResult()
    urls   = pdf_urls or DOE_PDF_URLS
    rdate  = report_date or date.today().isoformat()

    print(f"\n{'='*55}")
    print("DOE Fuel Allocation Scraper")
    print(f"  Report date: {rdate}")
    print(f"  PDF URLs to try: {len(urls)}")
    print(f"{'='*55}")

    for url in urls:
        pdf_bytes = await fetch_pdf(url)
        if not pdf_bytes:
            result.errors.append(f"Could not fetch: {url}")
            continue

        try:
            records = parse_pdf_bytes(pdf_bytes, rdate)
            if records:
                result.records.extend(records)
                result.source_url = url
                print(f"  Parsed {len(records)} Cebu records from PDF.")
                break  # Stop at first successful PDF
            else:
                result.errors.append(f"PDF parsed but 0 Cebu records found: {url}")
                print(f"  ⚠  PDF parsed but no Cebu municipality rows found.")
        except Exception as e:
            result.errors.append(f"PDF parse error ({url}): {e}")
            print(f"  ❌ Parse error: {e}")

    if not result.records:
        print("\n  ❌ No records scraped. All sources blocked or empty.")
        print("  Manual fallback: Download PDF from https://www.doe.gov.ph/petroleum-reports")
        print("  and pass it via: scrape_doe_fuel(pdf_urls=['file:///path/to/report.pdf'])")

    return result


# ── CSV output ────────────────────────────────────────────────────────────────

def save_csv(result: ScrapeResult, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["psgc_code", "municipality", "value", "date", "source"])
        writer.writeheader()
        for r in result.records:
            writer.writerow({
                "psgc_code":    r.psgc_code,
                "municipality": r.municipality,
                "value":        r.value,
                "date":         r.date,
                "source":       r.source,
            })
    print(f"  Saved → {path}  ({len(result.records)} rows)")


# ── CLI ───────────────────────────────────────────────────────────────────────

async def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="DOE fuel allocation scraper for Cebu")
    parser.add_argument("--date",   help="Report date (YYYY-MM-DD, default: today)")
    parser.add_argument("--pdf",    help="Path or URL to a specific PDF to parse")
    parser.add_argument("--out",    help="Output CSV path", default=str(OUTPUT_DIR / "doe_fuel_allocation.csv"))
    args = parser.parse_args()

    pdf_urls = [args.pdf] if args.pdf else None
    result   = await scrape_doe_fuel(report_date=args.date, pdf_urls=pdf_urls)

    out_path = Path(args.out)
    if result.records:
        save_csv(result, out_path)
        print(f"\n✅ Done. {len(result.records)} records.")
    else:
        print("\n⚠  No records to save.")
        if result.errors:
            print("Errors:")
            for e in result.errors:
                print(f"  • {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
