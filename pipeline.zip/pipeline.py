"""
pipeline.py — Data pipeline orchestrator for the Cebu LGU choropleth map.

Based on: docs/003-Data-Pipeline-Architecture.md

Coordinates:
  1. Boundary fetching (Geoboundaries ADM3)
  2. Dataset scraping (DOE, DOT-7, + stubs for DPWH, COMELEC, PSA, VECO)
  3. PSGC normalization
  4. CSV output per dataset + combined JSON for the map

Usage:
    python pipeline.py                    # run all datasets
    python pipeline.py --datasets doe dot # run specific datasets
    python pipeline.py --boundaries-only  # fetch boundaries only
    python pipeline.py --dry-run          # print plan, don't fetch
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

# ── Module imports ────────────────────────────────────────────────────────────

sys.path.insert(0, str(Path(__file__).parent))

from psgc import PSGC_TABLE, name_to_psgc, psgc_to_name
from geoboundaries import fetch_cebu_boundaries, save_geojson

from scraper_doe import scrape_doe_fuel,              save_csv as save_doe_csv
from scraper_dot import scrape_dot_tourist_arrivals,  save_csv as save_dot_csv
from scraper_stubs import (
    scrape_dpwh_motorist_volume,
    scrape_comelec_voter_registration,
    scrape_psa_demographics,
    scrape_veco_power,
)

OUTPUT_DIR = Path(__file__).parent / "output"

# ── Dataset registry ──────────────────────────────────────────────────────────

DATASETS = {
    "doe":     {
        "label":       "Fuel Allocation",
        "unit":        "liters",
        "scraper":     scrape_doe_fuel,
        "save_csv":    save_doe_csv,
        "output_csv":  "doe_fuel_allocation.csv",
        "status":      "active",      # active | stub
    },
    "dot":     {
        "label":       "Tourist Arrivals",
        "unit":        "visitors",
        "scraper":     scrape_dot_tourist_arrivals,
        "save_csv":    save_dot_csv,
        "output_csv":  "dot_tourist_arrivals.csv",
        "status":      "active",
    },
    "dpwh":    {
        "label":       "Motorist Volume",
        "unit":        "vehicles/day",
        "scraper":     scrape_dpwh_motorist_volume,
        "save_csv":    None,
        "output_csv":  "dpwh_motorist_volume.csv",
        "status":      "stub",
    },
    "comelec": {
        "label":       "Voter Registration",
        "unit":        "registered voters",
        "scraper":     scrape_comelec_voter_registration,
        "save_csv":    None,
        "output_csv":  "comelec_voter_registration.csv",
        "status":      "stub",
    },
    "psa":     {
        "label":       "Population",
        "unit":        "persons",
        "scraper":     scrape_psa_demographics,
        "save_csv":    None,
        "output_csv":  "psa_demographics.csv",
        "status":      "stub",
    },
    "veco":    {
        "label":       "Power Monitoring",
        "unit":        "MW",
        "scraper":     scrape_veco_power,
        "save_csv":    None,
        "output_csv":  "veco_power.csv",
        "status":      "stub",
    },
}

# ── Result types ──────────────────────────────────────────────────────────────

@dataclass
class DatasetResult:
    dataset_id:  str
    records:     list[dict] = field(default_factory=list)
    errors:      list[str]  = field(default_factory=list)
    source_url:  str = ""
    is_stub:     bool = False


@dataclass
class PipelineResult:
    boundaries:  dict | None = None        # GeoJSON FeatureCollection
    datasets:    list[DatasetResult] = field(default_factory=list)
    errors:      list[str]           = field(default_factory=list)
    started_at:  str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    finished_at: str = ""
    duration_s:  float = 0.0


# ── Normalization ─────────────────────────────────────────────────────────────

def normalize_records(raw_records: list, dataset_id: str) -> list[dict]:
    """
    Convert scraper output records to canonical pipeline format.
    Ensures every record has: psgc_code, municipality, value, date, source.
    Drops any record whose municipality can't be matched to a Cebu PSGC code.
    """
    normalized = []
    unmatched = []

    for r in raw_records:
        # Handle both dataclass and dict records
        if hasattr(r, "__dataclass_fields__"):
            rec = {f: getattr(r, f) for f in r.__dataclass_fields__}
        else:
            rec = dict(r)

        # Ensure psgc_code is set and valid
        psgc = rec.get("psgc_code") or name_to_psgc(rec.get("municipality", ""))
        if not psgc or psgc not in PSGC_TABLE:
            unmatched.append(rec.get("municipality", "?"))
            continue

        normalized.append({
            "psgc_code":    psgc,
            "municipality": psgc_to_name(psgc) or rec.get("municipality", ""),
            "value":        float(rec.get("value", 0)),
            "date":         rec.get("date", datetime.now(timezone.utc).date().isoformat()),
            "source":       rec.get("source", dataset_id.upper()),
        })

    if unmatched:
        print(f"  ⚠  {len(unmatched)} unmatched municipalities (not Cebu): {unmatched[:5]}")

    return normalized


# ── CSV helpers ───────────────────────────────────────────────────────────────

def write_csv(records: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["psgc_code", "municipality", "value", "date", "source"]
        )
        writer.writeheader()
        writer.writerows(records)
    print(f"  Saved CSV → {path}  ({len(records)} rows)")


# ── Combined output ───────────────────────────────────────────────────────────

def build_combined_json(results: list[DatasetResult]) -> dict:
    """
    Build a combined JSON output that can be loaded directly by the choropleth map.

    Format:
    {
      "meta": { "generated_at": ..., "datasets": [...] },
      "data": {
        "072201": {
          "municipality": "Cebu City",
          "doe":     125000,
          "dot":     45230,
          ...
        },
        ...
      }
    }
    """
    combined: dict[str, dict] = {}

    # Pre-populate all known municipalities
    for psgc, name in PSGC_TABLE.items():
        combined[psgc] = {"municipality": name}

    # Merge dataset records
    for ds_result in results:
        if not ds_result.records:
            continue
        for rec in ds_result.records:
            psgc = rec.get("psgc_code")
            if psgc and psgc in combined:
                combined[psgc][ds_result.dataset_id] = rec.get("value")

    return {
        "meta": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "datasets": [
                {
                    "id":     r.dataset_id,
                    "label":  DATASETS.get(r.dataset_id, {}).get("label", r.dataset_id),
                    "unit":   DATASETS.get(r.dataset_id, {}).get("unit", ""),
                    "count":  len(r.records),
                    "is_stub": r.is_stub,
                    "errors": r.errors,
                }
                for r in results
            ],
        },
        "data": combined,
    }


# ── Pipeline runner ───────────────────────────────────────────────────────────

async def run_pipeline(
    dataset_ids:     list[str],
    fetch_boundaries: bool = True,
    dry_run:         bool = False,
    report_date:     str | None = None,
) -> PipelineResult:
    """
    Run the full data pipeline.

    Args:
        dataset_ids:      List of dataset keys from DATASETS to run.
        fetch_boundaries: Whether to fetch GeoJSON boundaries.
        dry_run:          Print plan only, don't execute fetches.
        report_date:      ISO date for scraped data (default: today).
    """
    result = PipelineResult()
    t0 = datetime.now(timezone.utc)

    print(f"\n{'='*60}")
    print("Cebu LGU Data Pipeline")
    print(f"  Datasets:   {', '.join(dataset_ids)}")
    print(f"  Boundaries: {'yes' if fetch_boundaries else 'no'}")
    print(f"  Dry run:    {'yes' if dry_run else 'no'}")
    print(f"{'='*60}\n")

    if dry_run:
        print("DRY RUN — would execute:")
        if fetch_boundaries:
            print("  • Fetch Cebu ADM3 boundaries from Geoboundaries API")
        for ds_id in dataset_ids:
            ds = DATASETS.get(ds_id)
            if ds:
                status = "🔴 stub" if ds["status"] == "stub" else "✅ active"
                print(f"  • Scrape {ds['label']} ({ds_id}) [{status}]")
        return result

    # ── Step 1: Boundaries ────────────────────────────────────────────────────
    if fetch_boundaries:
        print("── Step 1: Fetching boundaries ──")
        try:
            geojson = await fetch_cebu_boundaries(simplified=False)
            result.boundaries = geojson
            out_path = OUTPUT_DIR / "boundaries_cebu.geojson"
            save_geojson(geojson, out_path)
        except Exception as e:
            msg = f"Boundary fetch failed: {e}"
            print(f"  ❌ {msg}")
            result.errors.append(msg)

    # ── Step 2: Datasets ──────────────────────────────────────────────────────
    print(f"\n── Step 2: Scraping {len(dataset_ids)} dataset(s) ──")

    for ds_id in dataset_ids:
        ds = DATASETS.get(ds_id)
        if not ds:
            print(f"  ⚠  Unknown dataset '{ds_id}' — skipping")
            continue

        print(f"\n  [{ds_id}] {ds['label']} ({ds['unit']})")
        is_stub = ds["status"] == "stub"

        try:
            scrape_result = await ds["scraper"](report_date=report_date)
            records = normalize_records(scrape_result.records, ds_id)

            ds_result = DatasetResult(
                dataset_id=ds_id,
                records=records,
                errors=scrape_result.errors,
                source_url=scrape_result.source_url,
                is_stub=is_stub,
            )

            # Save individual CSV
            if records:
                write_csv(records, OUTPUT_DIR / ds["output_csv"])
            else:
                print(f"  ⚠  No records for {ds_id}")

        except Exception as e:
            msg = f"Scraper error [{ds_id}]: {e}"
            print(f"  ❌ {msg}")
            ds_result = DatasetResult(
                dataset_id=ds_id,
                errors=[msg],
                is_stub=is_stub,
            )

        result.datasets.append(ds_result)

    # ── Step 3: Combined output ───────────────────────────────────────────────
    print("\n── Step 3: Writing combined output ──")

    combined = build_combined_json(result.datasets)
    combined_path = OUTPUT_DIR / "cebu_lgu_data.json"
    combined_path.parent.mkdir(parents=True, exist_ok=True)
    with open(combined_path, "w", encoding="utf-8") as f:
        json.dump(combined, f, ensure_ascii=False, indent=2)

    total_records = sum(len(r.records) for r in result.datasets)
    successful = sum(1 for r in result.datasets if r.records)
    stubbed = sum(1 for r in result.datasets if r.is_stub)

    print(f"  Saved combined JSON → {combined_path}")
    print(f"\n{'='*60}")
    print("Pipeline complete")
    print(f"  Datasets run:        {len(result.datasets)}")
    print(f"  With data:           {successful}")
    print(f"  Stubs (no data yet): {stubbed}")
    print(f"  Total records:       {total_records}")

    t1 = datetime.now(timezone.utc)
    result.finished_at = t1.isoformat()
    result.duration_s  = (t1 - t0).total_seconds()
    print(f"  Duration:            {result.duration_s:.1f}s")

    if result.errors:
        print(f"\n  Errors ({len(result.errors)}):")
        for e in result.errors:
            print(f"    • {e}")

    return result


# ── CLI ───────────────────────────────────────────────────────────────────────

async def main() -> None:
    parser = argparse.ArgumentParser(
        description="Cebu LGU data pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"Available datasets: {', '.join(DATASETS.keys())}",
    )
    parser.add_argument(
        "--datasets", nargs="+",
        default=list(DATASETS.keys()),
        help="Datasets to run (default: all)",
    )
    parser.add_argument(
        "--boundaries-only", action="store_true",
        help="Fetch boundaries only, skip scrapers",
    )
    parser.add_argument(
        "--no-boundaries", action="store_true",
        help="Skip boundary fetch",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print plan only",
    )
    parser.add_argument(
        "--date", help="Report date YYYY-MM-DD (default: today)",
    )
    args = parser.parse_args()

    if args.boundaries_only:
        dataset_ids = []
    else:
        # Validate dataset IDs
        unknown = [d for d in args.datasets if d not in DATASETS]
        if unknown:
            print(f"Unknown datasets: {unknown}")
            print(f"Available: {list(DATASETS.keys())}")
            sys.exit(1)
        dataset_ids = args.datasets

    await run_pipeline(
        dataset_ids=dataset_ids,
        fetch_boundaries=not args.no_boundaries,
        dry_run=args.dry_run,
        report_date=args.date,
    )


if __name__ == "__main__":
    asyncio.run(main())
