"""
scraper_dot.py — DOT-7 (Department of Tourism, Region 7) tourist arrivals scraper.

Strategy (per docs/001):
  Primary:  Parse PDF/Excel statistical reports from DOT Central Office.
  Fallback: Cloudscraper for DOT-7 regional page.
  Blocked:  Playwright stub (TODO) for JS-rendered pages.

Output CSV columns: psgc_code,municipality,value,date,source
Value unit: tourist arrivals (integer count)

Status as of April 2026:
  - dot7visayas.com: Connection refused
  - tourism.gov.ph: Partially accessible, statistics section untested
  - DOT publishes annual/quarterly PDF statistical reports
"""

from __future__ import annotations

import asyncio
import csv
import io
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, date, timezone
from pathlib import Path

import aiohttp

try:
    import cloudscraper
    _CLOUDSCRAPER_AVAILABLE = True
except ImportError:
    _CLOUDSCRAPER_AVAILABLE = False

try:
    import pdfplumber
    _PDFPLUMBER_AVAILABLE = True
except ImportError:
    _PDFPLUMBER_AVAILABLE = False

try:
    import fitz
    _FITZ_AVAILABLE = True
except ImportError:
    _FITZ_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    _BS4_AVAILABLE = True
except ImportError:
    _BS4_AVAILABLE = False

sys.path.insert(0, str(Path(__file__).parent))
from psgc import name_to_psgc, psgc_to_name

OUTPUT_DIR = Path(__file__).parent / "output"
SOURCE_TAG  = "DOT-7"

# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class TouristRecord:
    psgc_code:    str
    municipality: str
    value:        float          # tourist arrivals
    date:         str            # ISO date YYYY-MM-DD
    source:       str = SOURCE_TAG


@dataclass
class ScrapeResult:
    records:    list[TouristRecord] = field(default_factory=list)
    errors:     list[str]           = field(default_factory=list)
    source_url: str = ""
    fetched_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ── Known URLs ────────────────────────────────────────────────────────────────

# DOT Central statistical publications
DOT_CENTRAL_STATS_URL  = "https://www.tourism.gov.ph/tourism_dem_sup_pub.aspx"
DOT_CENTRAL_PDF_URLS   = [
    # Annual visitor statistics (DOT central publishes these as PDFs)
    "https://www.tourism.gov.ph/files/publication/visitor_statistics_latest.pdf",
    "https://www.tourism.gov.ph/files/publication/annual_report_latest.pdf",
    # Region 7 specific
    "https://dot7visayas.com/statistics/",
    "https://dot7visayas.com/tourist-arrivals/",
]

# PSA (Philippine Statistics Authority) tourism data — alternative source
PSA_TOURISM_URL = "https://openstat.psa.gov.ph/PXWeb/pxweb/en/DB/DB__4C/0040C4ETDOU1.px/"

# HTML table scraping targets — pages that publish tabular tourist arrival data
DOT_HTML_TARGETS = [
    "https://www.tourism.gov.ph/tourism_dem_sup_pub.aspx",
    "https://dot7visayas.com/statistics/",
]


# ── PDF parsing ───────────────────────────────────────────────────────────────

def _parse_pdf_pdfplumber(pdf_bytes: bytes, report_date: str) -> list[TouristRecord]:
    """
    Parse DOT PDF report. Looks for tables with municipality + arrivals columns.

    DOT reports typically format data as:
      Municipality/City | Domestic Arrivals | Foreign Arrivals | Total
    or
      LGU | Jan | Feb | ... | Total
    """
    records: list[TouristRecord] = []

    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for page in pdf.pages:
            tables = page.extract_tables()
            for table in tables:
                if not table or len(table) < 2:
                    continue

                header = [str(c).lower().strip() if c else "" for c in table[0]]

                # Identify municipality and total arrivals columns
                muni_col  = next(
                    (i for i, h in enumerate(header)
                     if any(k in h for k in ["municipality", "city", "lgu", "destination", "locality"])),
                    None,
                )
                total_col = next(
                    (i for i, h in enumerate(header)
                     if any(k in h for k in ["total", "arrivals", "visitors", "tourist"])),
                    None,
                )
                # If no explicit total, try the last numeric column
                if total_col is None and muni_col is not None:
                    total_col = len(header) - 1

                if muni_col is None:
                    continue

                for row in table[1:]:
                    if not row or len(row) <= max(
                        muni_col, total_col if total_col is not None else 0
                    ):
                        continue

                    muni_raw = str(row[muni_col] or "").strip()
                    val_raw  = str(row[total_col] or "").strip() if total_col is not None else ""

                    if not muni_raw or not val_raw:
                        continue

                    val_clean = re.sub(r"[^\d.]", "", val_raw)
                    if not val_clean:
                        continue

                    psgc = name_to_psgc(muni_raw)
                    if not psgc:
                        continue

                    records.append(TouristRecord(
                        psgc_code=psgc,
                        municipality=psgc_to_name(psgc) or muni_raw,
                        value=float(val_clean),
                        date=report_date,
                        source=SOURCE_TAG,
                    ))

    return records


def _parse_pdf_pymupdf(pdf_bytes: bytes, report_date: str) -> list[TouristRecord]:
    """PyMuPDF fallback — plain-text extraction with regex heuristics."""
    records: list[TouristRecord] = []
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")

    # Pattern: "Municipality Name    1,234,567"
    pattern = re.compile(
        r"([A-Za-z\-\s]+(?:City|Municipality)?)\s+([\d,]{3,})",
        re.IGNORECASE,
    )

    for page in doc:
        text = page.get_text()
        for match in pattern.finditer(text):
            muni_raw = match.group(1).strip()
            val_raw  = match.group(2).strip().replace(",", "")

            psgc = name_to_psgc(muni_raw)
            if not psgc:
                continue
            try:
                records.append(TouristRecord(
                    psgc_code=psgc,
                    municipality=psgc_to_name(psgc) or muni_raw,
                    value=float(val_raw),
                    date=report_date,
                    source=SOURCE_TAG,
                ))
            except ValueError:
                continue

    doc.close()
    return records


def parse_pdf_bytes(pdf_bytes: bytes, report_date: str) -> list[TouristRecord]:
    if _PDFPLUMBER_AVAILABLE:
        return _parse_pdf_pdfplumber(pdf_bytes, report_date)
    elif _FITZ_AVAILABLE:
        return _parse_pdf_pymupdf(pdf_bytes, report_date)
    else:
        raise RuntimeError(
            "No PDF library available.\n"
            "Install: pip install pdfplumber   (preferred)\n"
            "     or: pip install pymupdf"
        )


# ── HTML table parsing ────────────────────────────────────────────────────────

def parse_html_tables(html: str, report_date: str) -> list[TouristRecord]:
    """
    Parse tourist arrival data from an HTML page.
    Looks for <table> elements containing municipality and arrival count columns.
    """
    if not _BS4_AVAILABLE:
        raise RuntimeError("BeautifulSoup not installed: pip install beautifulsoup4")

    records: list[TouristRecord] = []
    soup = BeautifulSoup(html, "html.parser")

    for table in soup.find_all("table"):
        rows = table.find_all("tr")
        if len(rows) < 2:
            continue

        # Parse header
        header_cells = rows[0].find_all(["th", "td"])
        header = [c.get_text(strip=True).lower() for c in header_cells]

        muni_col  = next(
            (i for i, h in enumerate(header)
             if any(k in h for k in ["municipality", "city", "lgu", "destination"])),
            None,
        )
        total_col = next(
            (i for i, h in enumerate(header)
             if any(k in h for k in ["total", "arrivals", "visitors"])),
            len(header) - 1,
        )

        if muni_col is None:
            continue

        for row in rows[1:]:
            cells = row.find_all(["td", "th"])
            if len(cells) <= max(muni_col, total_col):
                continue

            muni_raw = cells[muni_col].get_text(strip=True)
            val_raw  = cells[total_col].get_text(strip=True)
            val_clean = re.sub(r"[^\d.]", "", val_raw)

            if not muni_raw or not val_clean:
                continue

            psgc = name_to_psgc(muni_raw)
            if not psgc:
                continue

            try:
                records.append(TouristRecord(
                    psgc_code=psgc,
                    municipality=psgc_to_name(psgc) or muni_raw,
                    value=float(val_clean),
                    date=report_date,
                    source=SOURCE_TAG,
                ))
            except ValueError:
                continue

    return records


# ── HTTP fetching ─────────────────────────────────────────────────────────────

async def _fetch_aiohttp(url: str) -> tuple[bytes | None, str]:
    """Returns (content, content_type)."""
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
    }
    try:
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=60)) as resp:
                if resp.status == 200:
                    ct = resp.headers.get("Content-Type", "")
                    return await resp.read(), ct
                print(f"  HTTP {resp.status} from {url}")
    except Exception as e:
        print(f"  aiohttp error on {url}: {e}")
    return None, ""


def _fetch_cloudscraper(url: str) -> tuple[bytes | None, str]:
    if not _CLOUDSCRAPER_AVAILABLE:
        return None, ""
    try:
        scraper = cloudscraper.create_scraper()
        resp = scraper.get(url, timeout=60)
        if resp.status_code == 200:
            return resp.content, resp.headers.get("Content-Type", "")
        print(f"  cloudscraper HTTP {resp.status_code}")
    except Exception as e:
        print(f"  cloudscraper error: {e}")
    return None, ""


async def _fetch_playwright(url: str) -> tuple[bytes | None, str]:
    """
    TODO: Playwright fallback for Cloudflare-protected DOT pages.

    Implementation plan:
      1. pip install playwright && playwright install chromium
      2. Launch browser with stealth settings
      3. Navigate to DOT statistics page
      4. Wait for table to render (networkidle or selector)
      5. Extract page HTML or click PDF download link
      6. Return content + content type

    DOT Central target: https://www.tourism.gov.ph/tourism_dem_sup_pub.aspx
    DOT-7 target:       https://dot7visayas.com/statistics/
    """
    raise NotImplementedError(
        "Playwright not implemented yet.\n"
        "To implement, see the TODO above in _fetch_playwright().\n"
        f"Target URL: {url}"
    )


async def fetch_resource(url: str) -> tuple[bytes | None, str]:
    """
    Fetch a URL with progressive fallback: aiohttp → cloudscraper → playwright.
    Returns (content_bytes, content_type).
    """
    print(f"  Fetching: {url}")

    content, ct = await _fetch_aiohttp(url)
    if content:
        print(f"  ✅ aiohttp succeeded ({len(content):,} bytes)")
        return content, ct

    if _CLOUDSCRAPER_AVAILABLE:
        print("  Retrying with cloudscraper...")
        content, ct = _fetch_cloudscraper(url)
        if content:
            print(f"  ✅ cloudscraper succeeded ({len(content):,} bytes)")
            return content, ct

    print("  ⚠  All fetch methods failed. (Playwright is TODO)")
    return None, ""


# ── Main scraper ──────────────────────────────────────────────────────────────

async def scrape_dot_tourist_arrivals(
    report_date: str | None = None,
    urls: list[str] | None = None,
) -> ScrapeResult:
    """
    Scrape DOT-7 tourist arrival data for Cebu municipalities.

    Tries PDF reports first, falls back to HTML table parsing.
    """
    result = ScrapeResult()
    target_urls = urls or DOT_CENTRAL_PDF_URLS
    rdate = report_date or date.today().isoformat()

    print(f"\n{'='*55}")
    print("DOT-7 Tourist Arrivals Scraper")
    print(f"  Report date: {rdate}")
    print(f"  URLs to try: {len(target_urls)}")
    print(f"{'='*55}")

    for url in target_urls:
        content, ct = await fetch_resource(url)
        if not content:
            result.errors.append(f"Fetch failed: {url}")
            continue

        records: list[TouristRecord] = []

        # Dispatch based on content type
        if "pdf" in ct.lower() or content[:4] == b"%PDF":
            try:
                records = parse_pdf_bytes(content, rdate)
            except Exception as e:
                result.errors.append(f"PDF parse error ({url}): {e}")
                print(f"  ❌ PDF parse error: {e}")
        elif "html" in ct.lower() or content[:5] in (b"<html", b"<!DOC"):
            try:
                records = parse_html_tables(content.decode("utf-8", errors="ignore"), rdate)
            except Exception as e:
                result.errors.append(f"HTML parse error ({url}): {e}")
                print(f"  ❌ HTML parse error: {e}")
        else:
            result.errors.append(f"Unknown content type '{ct}' from {url}")
            continue

        if records:
            result.records.extend(records)
            result.source_url = url
            print(f"  Parsed {len(records)} Cebu records.")
            break
        else:
            result.errors.append(f"No Cebu records found in: {url}")
            print("  ⚠  Content fetched but no Cebu municipality rows matched.")

    if not result.records:
        print("\n  ❌ No records scraped.")
        print("  Manual fallback: Download from https://www.tourism.gov.ph/tourism_dem_sup_pub.aspx")
        print("  and pass via: scrape_dot_tourist_arrivals(urls=['file:///path/to/report.pdf'])")

    return result


# ── CSV output ────────────────────────────────────────────────────────────────

def save_csv(result: ScrapeResult, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["psgc_code", "municipality", "value", "date", "source"])
        writer.writeheader()
        for r in result.records:
            writer.writerow({
                "psgc_code":    r.psgc_code,
                "municipality": r.municipality,
                "value":        r.value,
                "date":         r.date,
                "source":       r.source,
            })
    print(f"  Saved → {path}  ({len(result.records)} rows)")


# ── CLI ───────────────────────────────────────────────────────────────────────

async def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="DOT-7 tourist arrivals scraper for Cebu")
    parser.add_argument("--date", help="Report date YYYY-MM-DD (default: today)")
    parser.add_argument("--url",  help="Specific URL or file path to parse")
    parser.add_argument("--out",  default=str(OUTPUT_DIR / "dot_tourist_arrivals.csv"))
    args = parser.parse_args()

    target_urls = [args.url] if args.url else None
    result = await scrape_dot_tourist_arrivals(report_date=args.date, urls=target_urls)

    if result.records:
        save_csv(result, Path(args.out))
        print(f"\n✅ Done. {len(result.records)} records.")
    else:
        print("\n⚠  No records to save.")
        for e in result.errors:
            print(f"  • {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
