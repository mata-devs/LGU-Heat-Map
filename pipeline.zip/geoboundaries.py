"""
geoboundaries.py — Fetch authoritative Cebu ADM3 boundary GeoJSON from Geoboundaries API.

Based on: docs/002-Geoboundaries-HDX-Integration.md

Usage:
    python geoboundaries.py                    # fetch + save cebu_boundaries.geojson
    python geoboundaries.py --simplified       # use simplified geometry (smaller file)
    python geoboundaries.py --all-phl          # dump full Philippines ADM3 (no Cebu filter)
    python geoboundaries.py --check            # print metadata only, don't download GeoJSON
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import aiohttp

# ── Constants ─────────────────────────────────────────────────────────────────

GEOBOUNDARIES_META_URL = "https://www.geoboundaries.org/api/current/gbOpen/PHL/ADM3/"
CEBU_PSGC_PREFIX = "0722"

# Property keys Geoboundaries uses for PSGC/pcode — try all variants
PCODE_KEYS = ("pcode", "ADM3_PCODE", "shapeID", "GID_3")
NAME_KEYS  = ("ADM3_EN", "shapeName", "NAME_3", "name")

OUTPUT_DIR = Path(__file__).parent / "output"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_prop(props: dict, keys: tuple[str, ...], default: str = "") -> str:
    for k in keys:
        if k in props and props[k]:
            return str(props[k])
    return default


def filter_cebu(geojson: dict) -> dict:
    """Keep only features whose pcode starts with 0722 (Cebu Province)."""
    features = geojson.get("features", [])
    cebu = [
        f for f in features
        if _get_prop(f.get("properties", {}), PCODE_KEYS).startswith(CEBU_PSGC_PREFIX)
    ]
    return {**geojson, "features": cebu}


def annotate_features(geojson: dict) -> dict:
    """
    Add a normalised 'municipality' property to every feature so
    downstream pipeline modules don't need to know the raw field names.
    """
    for f in geojson.get("features", []):
        props = f.setdefault("properties", {})
        props["municipality"] = _get_prop(props, NAME_KEYS)
        props["psgc_code"]    = _get_prop(props, PCODE_KEYS)
    return geojson


# ── Fetch logic ───────────────────────────────────────────────────────────────

async def fetch_meta(session: aiohttp.ClientSession) -> dict:
    """Fetch Geoboundaries metadata for PHL ADM3."""
    async with session.get(GEOBOUNDARIES_META_URL, timeout=aiohttp.ClientTimeout(total=30)) as resp:
        resp.raise_for_status()
        return await resp.json()


async def fetch_geojson(session: aiohttp.ClientSession, url: str) -> dict:
    """Download the actual GeoJSON file (can be large — ~50 MB for full PHL ADM3)."""
    print(f"  Downloading GeoJSON from: {url}")
    async with session.get(url, timeout=aiohttp.ClientTimeout(total=120)) as resp:
        resp.raise_for_status()
        text = await resp.text()
        return json.loads(text)


async def fetch_cebu_boundaries(
    simplified: bool = False,
    filter_to_cebu: bool = True,
) -> dict:
    """
    Main entry point. Returns a GeoJSON FeatureCollection of Cebu ADM3 municipalities.

    Args:
        simplified:      Use simplified geometry (smaller file, less detail).
        filter_to_cebu:  If False, return all Philippines ADM3 features.
    """
    headers = {
        "User-Agent": "CebuLGUHeatmap/1.0 (data pipeline; contact via github)",
        "Accept": "application/json",
    }

    async with aiohttp.ClientSession(headers=headers) as session:
        # Step 1: fetch metadata to get the download URLs
        print("Fetching Geoboundaries metadata...")
        meta = await fetch_meta(session)

        print(f"  Boundary source:  {meta.get('boundarySource', 'unknown')}")
        print(f"  Year represented: {meta.get('boundaryYearRepresented', 'unknown')}")
        print(f"  ADM unit count:   {meta.get('admUnitCount', 'unknown')}")
        print(f"  Build date:       {meta.get('buildDate', 'unknown')}")

        # Step 2: pick full or simplified geometry URL
        if simplified:
            url = meta.get("simplifiedGeometryGeoJSON")
            if not url:
                print("  ⚠  Simplified URL not in metadata, falling back to full geometry.")
                url = meta.get("gjDownloadURL")
        else:
            url = meta.get("gjDownloadURL")

        if not url:
            raise RuntimeError("Geoboundaries metadata did not include a GeoJSON download URL.")

        # Step 3: download
        geojson = await fetch_geojson(session, url)
        total = len(geojson.get("features", []))
        print(f"  Total ADM3 features (Philippines): {total}")

        # Step 4: filter + annotate
        if filter_to_cebu:
            geojson = filter_cebu(geojson)
            cebu_count = len(geojson.get("features", []))
            print(f"  Cebu ADM3 features after filter:   {cebu_count}")
            if cebu_count == 0:
                print("  ⚠  No Cebu features found — PSGC prefix filter may not match this dataset.")
                print("     Inspecting first 3 feature pcodes for debugging:")
                for f in geojson.get("features", [])[:3]:
                    props = f.get("properties", {})
                    print(f"     {props}")

        geojson = annotate_features(geojson)

        # Embed fetch metadata
        geojson["_meta"] = {
            "source":           "Geoboundaries",
            "source_url":       GEOBOUNDARIES_META_URL,
            "boundary_source":  meta.get("boundarySource"),
            "year_represented": meta.get("boundaryYearRepresented"),
            "fetched_at":       datetime.now(timezone.utc).isoformat(),
            "simplified":       simplified,
            "filtered_to_cebu": filter_to_cebu,
            "license":          "CC BY 3.0 IGO",
        }

        return geojson


# ── HDX fallback ──────────────────────────────────────────────────────────────

async def fetch_hdx_metadata() -> dict:
    """
    Fetch HDX dataset metadata for Philippine boundaries.
    HDX provides shapefiles — direct GeoJSON not available without conversion.
    Use this to check availability and get download links.
    """
    HDX_API = "https://data.humdata.org/api/3/action/package_show?id=cod-ab-phl"
    async with aiohttp.ClientSession() as session:
        async with session.get(HDX_API, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            resp.raise_for_status()
            data = await resp.json()
            return data.get("result", {})


# ── Output ────────────────────────────────────────────────────────────────────

def save_geojson(geojson: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False, indent=2)
    size_kb = path.stat().st_size / 1024
    print(f"  Saved → {path}  ({size_kb:.1f} KB)")


def print_municipality_list(geojson: dict) -> None:
    """Print the list of municipalities found in the fetched GeoJSON."""
    features = geojson.get("features", [])
    print(f"\nMunicipalities in fetched GeoJSON ({len(features)}):")
    for f in sorted(features, key=lambda x: x["properties"].get("psgc_code", "")):
        p = f["properties"]
        print(f"  {p.get('psgc_code', '?'):10s}  {p.get('municipality', '?')}")


# ── CLI ───────────────────────────────────────────────────────────────────────

async def main(args: argparse.Namespace) -> None:
    if args.check:
        print("Checking Geoboundaries metadata (no download)...")
        async with aiohttp.ClientSession() as session:
            meta = await fetch_meta(session)
        print(json.dumps(meta, indent=2))
        return

    print(f"\n{'='*55}")
    print("Geoboundaries Fetcher — Cebu ADM3 Boundaries")
    print(f"{'='*55}")

    geojson = await fetch_cebu_boundaries(
        simplified=args.simplified,
        filter_to_cebu=not args.all_phl,
    )

    if args.list:
        print_municipality_list(geojson)

    suffix = "_simplified" if args.simplified else ""
    scope  = "_all_phl" if args.all_phl else "_cebu"
    out_path = OUTPUT_DIR / f"boundaries{scope}{suffix}.geojson"
    save_geojson(geojson, out_path)

    print(f"\n✅ Done. {len(geojson.get('features', []))} features saved.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch Cebu ADM3 boundaries from Geoboundaries API")
    parser.add_argument("--simplified", action="store_true", help="Use simplified geometry (smaller file)")
    parser.add_argument("--all-phl",    action="store_true", help="Skip Cebu filter, return all Philippines ADM3")
    parser.add_argument("--check",      action="store_true", help="Print metadata only, no download")
    parser.add_argument("--list",       action="store_true", help="Print municipality list after fetching")
    args = parser.parse_args()

    asyncio.run(main(args))
